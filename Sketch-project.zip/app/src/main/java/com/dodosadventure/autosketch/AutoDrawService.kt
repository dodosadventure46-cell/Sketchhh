package com.dodosadventure.autosketch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class AutoDrawService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoDrawService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var boxView: BoxView? = null
    private var barView: View? = null
    private var boxLp: WindowManager.LayoutParams? = null
    private var sketch: Bitmap? = null

    private var drawing = false
    private var strokes: List<List<PointF>> = emptyList()
    private var idx = 0
    private var speed = 0.09f // piksel per milidetik

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        endDrawing(null)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    /** Menampilkan kotak + bar kontrol. Mengembalikan false jika gagal. */
    fun showOverlay(): Boolean {
        val manager = wm ?: return false
        if (boxView != null) return true

        val file = File(filesDir, "sketch.png")
        val bmp = if (file.exists()) BitmapFactory.decodeFile(file.path) else null
        if (bmp == null) {
            toast("Pilih gambar sketsa dulu di aplikasi")
            return false
        }
        sketch = bmp

        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.7f).toInt()
        val h = (w * bmp.height.toFloat() / bmp.width).toInt()
            .coerceIn(dp(120), (dm.heightPixels * 0.7f).toInt())

        val blp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels - w) / 2
            y = (dm.heightPixels - h) / 2
        }
        boxLp = blp

        val box = BoxView(this, bmp)
        box.onMove = { dx, dy ->
            blp.x += dx
            blp.y += dy
            manager.updateViewLayout(box, blp)
        }
        box.onResize = { dx, dy ->
            blp.width = max(dp(80), blp.width + dx)
            blp.height = max(dp(80), blp.height + dy)
            manager.updateViewLayout(box, blp)
        }
        manager.addView(box, blp)
        boxView = box

        // Bar kontrol (terpisah dari kotak supaya tetap bisa disentuh saat menggambar)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC222222.toInt())
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val barLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(120)
        }

        var lx = 0f
        var ly = 0f
        val grip = TextView(this).apply {
            text = "\u2630"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(14), 0)
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        lx = ev.rawX
                        ly = ev.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        barLp.x += (ev.rawX - lx).toInt()
                        barLp.y += (ev.rawY - ly).toInt()
                        lx = ev.rawX
                        ly = ev.rawY
                        manager.updateViewLayout(bar, barLp)
                    }
                }
                true
            }
        }

        fun makeButton(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { onClick() }
        }

        bar.addView(grip)
        bar.addView(makeButton("\u25B6 Gambar") { startDrawing() })
        bar.addView(makeButton("\u25A0 Stop") { endDrawing("Dihentikan") })
        bar.addView(makeButton("\u2715 Tutup") { hideOverlay() })
        manager.addView(bar, barLp)
        barView = bar
        return true
    }

    fun hideOverlay() {
        endDrawing(null)
        val manager = wm
        try {
            boxView?.let { manager?.removeView(it) }
        } catch (_: Exception) {
        }
        try {
            barView?.let { manager?.removeView(it) }
        } catch (_: Exception) {
        }
        boxView = null
        barView = null
        boxLp = null
        sketch = null
    }

    private fun setBoxTouchable(touchable: Boolean) {
        val box = boxView ?: return
        val lp = boxLp ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        box.previewVisible = touchable
        try {
            wm?.updateViewLayout(box, lp)
        } catch (_: Exception) {
        }
        box.invalidate()
    }

    private fun startDrawing() {
        val box = boxView ?: return
        val bmp = sketch ?: return
        if (drawing) return

        val loc = IntArray(2)
        box.getLocationOnScreen(loc)
        val bw = box.width
        val bh = box.height

        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val detail = prefs.getInt("detail", 120)
        val threshold = prefs.getInt("thr", 80)
        val lineArt = prefs.getBoolean("lineArt", false)
        speed = prefs.getInt("speed", 3) * 0.03f

        drawing = true
        toast("Menyiapkan garis...")
        Thread {
            val raw = SketchProcessor.trace(bmp, bw, bh, detail, threshold, lineArt)
            val mapped = raw.map { st -> st.map { PointF(it.x + loc[0], it.y + loc[1]) } }
            handler.post {
                if (!drawing) return@post
                if (mapped.isEmpty()) {
                    drawing = false
                    toast("Tidak ada garis terdeteksi. Coba turunkan ambang.")
                    return@post
                }
                strokes = mapped
                idx = 0
                setBoxTouchable(false)
                handler.postDelayed({ nextBatch() }, 300)
            }
        }.start()
    }

    private fun pathLength(pts: List<PointF>): Float {
        var len = 0f
        for (i in 1 until pts.size) {
            len += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        }
        return len
    }

    private fun nextBatch() {
        if (!drawing) return
        if (idx >= strokes.size) {
            endDrawing("Selesai")
            return
        }
        val maxStrokes = min(8, GestureDescription.getMaxStrokeCount())
        val builder = GestureDescription.Builder()
        var t = 0L
        var count = 0
        while (idx < strokes.size && count < maxStrokes && t < 3000L) {
            val pts = strokes[idx++]
            val len = pathLength(pts)
            if (len < 1f) continue
            val path = Path()
            path.moveTo(pts[0].x, pts[0].y)
            for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
            val dur = max(40L, (len / speed).toLong())
            builder.addStroke(GestureDescription.StrokeDescription(path, t, dur))
            t += dur + 30L
            count++
        }
        if (count == 0) {
            handler.post { nextBatch() }
            return
        }
        val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                handler.post { nextBatch() }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                handler.post { endDrawing("Gestur dibatalkan sistem") }
            }
        }, null)
        if (!ok) endDrawing("Gagal mengirim gestur")
    }

    private fun endDrawing(msg: String?) {
        val wasDrawing = drawing
        drawing = false
        if (wasDrawing) {
            setBoxTouchable(true)
            if (msg != null) toast(msg)
        }
    }
}
