package com.dodosadventure.autosketch

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mengubah gambar menjadi daftar goresan (stroke).
 * Alur: deteksi garis -> tutup celah kecil -> tipiskan jadi 1 piksel (skeleton)
 * -> telusuri menjadi goresan panjang -> sambung goresan yang hampir bersentuhan.
 * Koordinat hasil relatif terhadap pojok kiri-atas kotak (dalam piksel layar).
 */
object SketchProcessor {
    private val DX = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
    private val DY = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)

    // Celah maksimal (dalam sel grid) yang masih disambung menjadi satu goresan
    private const val MAX_GAP = 3

    fun trace(
        src: Bitmap,
        boxW: Int,
        boxH: Int,
        detail: Int,
        threshold: Int,
        lineArt: Boolean
    ): List<List<PointF>> {
        val ratio = detail.toFloat() / max(src.width, src.height)
        val gw = max(8, (src.width * ratio).roundToInt())
        val gh = max(8, (src.height * ratio).roundToInt())
        val small = Bitmap.createScaledBitmap(src, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        val n = gw * gh

        val gray = IntArray(n) { i ->
            val c = px[i]
            if (Color.alpha(c) < 128) 255
            else (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)).toInt()
        }

        val edge = BooleanArray(n)
        if (lineArt) {
            val limit = 255 - threshold
            for (i in 0 until n) edge[i] = gray[i] < limit
        } else {
            for (y in 1 until gh - 1) {
                for (x in 1 until gw - 1) {
                    val i = y * gw + x
                    val gx = -gray[i - gw - 1] + gray[i - gw + 1] -
                        2 * gray[i - 1] + 2 * gray[i + 1] -
                        gray[i + gw - 1] + gray[i + gw + 1]
                    val gy = -gray[i - gw - 1] - 2 * gray[i - gw] - gray[i - gw + 1] +
                        gray[i + gw - 1] + 2 * gray[i + gw] + gray[i + gw + 1]
                    edge[i] = (abs(gx) + abs(gy)) / 4 > threshold
                }
            }
        }

        // 1) tutup celah kecil lalu tipiskan menjadi garis 1 piksel
        val skel = dilate(edge, gw, gh)
        thin(skel, gw, gh)

        // 2) telusuri skeleton menjadi rantai piksel
        val visited = BooleanArray(n)
        val chains = ArrayList<ArrayList<Int>?>()

        fun neighborCount(i: Int): Int {
            val cx = i % gw
            val cy = i / gw
            var c = 0
            for (k in 0 until 8) {
                val nx = cx + DX[k]
                val ny = cy + DY[k]
                if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                if (skel[ny * gw + nx]) c++
            }
            return c
        }

        fun visitedNeighbor(i: Int): Int {
            val cx = i % gw
            val cy = i / gw
            for (k in 0 until 8) {
                val nx = cx + DX[k]
                val ny = cy + DY[k]
                if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                val ni = ny * gw + nx
                if (skel[ni] && visited[ni]) return ni
            }
            return -1
        }

        fun walk(start: Int, prefix: Int) {
            val chain = ArrayList<Int>()
            if (prefix >= 0) chain.add(prefix)
            var cur = start
            var dir = -1
            visited[cur] = true
            chain.add(cur)
            while (true) {
                val cx = cur % gw
                val cy = cur / gw
                var best = -1
                var bestK = -1
                var bestScore = -1
                for (k in 0 until 8) {
                    val nx = cx + DX[k]
                    val ny = cy + DY[k]
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (!skel[ni] || visited[ni]) continue
                    val score = if (dir < 0) 4 else {
                        val d = abs(k - dir)
                        4 - min(d, 8 - d)
                    }
                    if (score > bestScore) {
                        bestScore = score
                        best = ni
                        bestK = k
                    }
                }
                if (best < 0) break
                cur = best
                dir = bestK
                visited[cur] = true
                chain.add(cur)
            }
            // sambungkan ujung ke persimpangan / garis yang sudah dilewati
            if (chain.size >= 2) {
                val cx = cur % gw
                val cy = cur / gw
                val prev = chain[chain.size - 2]
                val prev2 = if (chain.size >= 3) chain[chain.size - 3] else -1
                for (k in 0 until 8) {
                    val nx = cx + DX[k]
                    val ny = cy + DY[k]
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (skel[ni] && visited[ni] && ni != prev && ni != prev2 && ni != cur) {
                        chain.add(ni)
                        break
                    }
                }
            }
            chains.add(chain)
        }

        // mulai dari ujung garis dulu, lalu sisanya (loop / cabang)
        for (i in 0 until n) {
            if (skel[i] && !visited[i] && neighborCount(i) == 1) walk(i, visitedNeighbor(i))
        }
        for (i in 0 until n) {
            if (skel[i] && !visited[i]) walk(i, visitedNeighbor(i))
        }

        // 3) sambung goresan yang ujungnya berdekatan (menghilangkan garis putus-putus)
        fun d2(a: Int, b: Int): Int {
            val dx = a % gw - b % gw
            val dy = a / gw - b / gw
            return dx * dx + dy * dy
        }
        val maxGap2 = MAX_GAP * MAX_GAP
        for (i in chains.indices) {
            val c = chains[i] ?: continue
            for (pass in 0 until 2) {
                while (true) {
                    val tail = c[c.size - 1]
                    var bj = -1
                    var bEnd = false
                    var bd = Int.MAX_VALUE
                    for (j in chains.indices) {
                        if (j == i) continue
                        val o = chains[j] ?: continue
                        val ds = d2(tail, o[0])
                        val de = d2(tail, o[o.size - 1])
                        if (ds < bd) {
                            bd = ds; bj = j; bEnd = false
                        }
                        if (de < bd) {
                            bd = de; bj = j; bEnd = true
                        }
                    }
                    if (bj < 0 || bd > maxGap2) break
                    val o = chains[bj]!!
                    if (bEnd) o.reverse()
                    c.addAll(o)
                    chains[bj] = null
                }
                c.reverse()
            }
        }

        // 4) petakan ke koordinat kotak
        val fit = min(boxW.toFloat() / gw, boxH.toFloat() / gh)
        val ox = (boxW - gw * fit) / 2f
        val oy = (boxH - gh * fit) / 2f
        fun toPoint(p: Int) = PointF(ox + ((p % gw) + 0.5f) * fit, oy + ((p / gw) + 0.5f) * fit)

        val result = ArrayList<List<PointF>>()
        for (c in chains) {
            if (c == null || c.size < 6) continue
            if (c.size >= 8 && d2(c[0], c[c.size - 1]) <= 4) c.add(c[0]) // tutup loop
            val pts = ArrayList<PointF>()
            var i = 0
            while (i < c.size) {
                pts.add(toPoint(c[i]))
                i += 2
            }
            if ((c.size - 1) % 2 != 0) pts.add(toPoint(c[c.size - 1]))
            result.add(pts)
        }
        return result
    }

    private fun dilate(src: BooleanArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                out[i] = src[i] || src[i - 1] || src[i + 1] ||
                    src[i - w] || src[i + w] ||
                    src[i - w - 1] || src[i - w + 1] || src[i + w - 1] || src[i + w + 1]
            }
        }
        return out
    }

    private fun bi(v: Boolean): Int = if (v) 1 else 0

    /** Zhang-Suen thinning: garis tebal -> garis 1 piksel. */
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val toClear = ArrayList<Int>()
        var changed = true
        var guard = 0
        while (changed && guard < 60) {
            changed = false
            guard++
            for (step in 0..1) {
                toClear.clear()
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        val b = bi(p2) + bi(p3) + bi(p4) + bi(p5) + bi(p6) + bi(p7) + bi(p8) + bi(p9)
                        if (b < 2 || b > 6) continue
                        val a = bi(!p2 && p3) + bi(!p3 && p4) + bi(!p4 && p5) + bi(!p5 && p6) +
                            bi(!p6 && p7) + bi(!p7 && p8) + bi(!p8 && p9) + bi(!p9 && p2)
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        toClear.add(i)
                    }
                }
                if (toClear.isNotEmpty()) {
                    changed = true
                    for (i in toClear) img[i] = false
                }
            }
        }
    }
}
