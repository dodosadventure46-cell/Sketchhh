# Sketch (Auto Sketch)

APK Android dengan kotak mengambang. Gambar sketsa dipilih, lalu "jari" virtual
menggambarnya otomatis di dalam kotak yang bisa digeser dan diubah ukurannya.

## Build
Push ke GitHub, lalu buka tab **Actions** > **Build APK** > unduh artifact `AutoSketch-debug-apk`.
Atau buka folder ini di Android Studio dan jalankan `assembleDebug`.

## Cara pakai
1. Pasang APK, buka aplikasi, aktifkan layanan Accessibility "Auto Sketch".
2. Pilih gambar sketsa dan atur detail / ambang / kecepatan.
3. Tekan "Tampilkan kotak mengambang", buka aplikasi gambar tujuan.
4. Geser kotak, tarik segitiga di pojok kanan-bawah untuk mengubah ukuran.
5. Tekan "Gambar" di bar kontrol. "Stop" untuk menghentikan.
